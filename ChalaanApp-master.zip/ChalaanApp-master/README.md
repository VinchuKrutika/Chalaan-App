# Chalaan App

This was our Diploma Final Year Project based on RTO system 

College Name : Government Polytechnic Mumbai 
Department : Computer Engineering
Team Member : 
1. Dhanshree Patangrao 
2. Krutika Vinchu
3. Sayli Nagane 
4. Prachi Joshi 

## About App : 

“CHALAAN” application is designed to reduce the work of traffic police officers
as well as for the vehicle owners. In densely populated country like India patience
runs thin and forces the people to break the law. This application is designed to keep
a track of rules broken by a user as well as making it easier and safer for police to
make a chalaan bill.

Our project is based on RTO application, RTO is a Regional Transport Office
or Regional Transport Authority (RTO / RTA) is the organization of the Indian
government responsible for maintaining a database of drivers and a database of
vehicles for various states of India. The RTO issues driving license, organizes
collection of vehicle road tax and road fund license and sells personalized
registrations.
As we know that most of the people driving on road break the rule while the
signal is red, so main motive of our application is to capture the photo of that vehicle
send to that appropriate driver with fine of breaking the rules.

## Flow Chart :

![image](https://user-images.githubusercontent.com/55869458/216381795-3f729e11-6279-4762-abfd-7c424f4140b4.png)
