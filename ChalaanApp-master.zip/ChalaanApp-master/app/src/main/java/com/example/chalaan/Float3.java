package com.example.chalaan;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Float3 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_float3);
    }
}
