package com.example.chalaan.Activities.ui.home;

class MostViewedHelperClass {

    int imageview;
    String textview;

    public MostViewedHelperClass(int imageview, String textview) {
        this.imageview = imageview;
        this.textview = textview;
    }

    public int getImageview() {
        return imageview;
    }

    public String getTextview() {
        return textview;
    }
}
